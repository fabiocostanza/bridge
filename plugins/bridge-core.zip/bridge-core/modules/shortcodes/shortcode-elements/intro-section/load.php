<?php

require_once BRIDGE_CORE_SHORTCODES_PATH.'/intro-section/functions.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/intro-section/intro-section.php';
